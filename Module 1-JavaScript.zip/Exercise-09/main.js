
function fetchEvents() {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve([{ name: "Music Night" }]);
    }, 1000);
  });
}

// Using then/catch
fetchEvents()
  .then(data => console.log("Fetched:", data))
  .catch(err => console.error(err));

// Async/await version
async function loadEvents() {
  console.log("Loading...");
  try {
    const data = await fetchEvents();
    console.log("Data:", data);
  } catch (e) {
    console.error(e);
  }
}
loadEvents();
