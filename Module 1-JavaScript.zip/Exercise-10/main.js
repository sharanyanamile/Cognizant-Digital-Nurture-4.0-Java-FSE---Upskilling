
const events = [{ name: "Play", date: "2025-06-20" }];

function display({ name, date }) {
  console.log(`Upcoming: ${name} on ${date}`);
}

const cloned = [...events];
display(cloned[0]);
