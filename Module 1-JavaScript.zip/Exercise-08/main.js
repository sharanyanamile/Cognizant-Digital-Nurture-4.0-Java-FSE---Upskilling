
document.getElementById("registerBtn").onclick = () => {
  alert("Registered!");
};

document.getElementById("category").onchange = (e) => {
  console.log("Category selected:", e.target.value);
};

document.getElementById("search").onkeydown = (e) => {
  console.log("Search key:", e.key);
};
