
document.getElementById("regForm").addEventListener("submit", function(e) {
  e.preventDefault();
  const { name, email, event } = this.elements;
  if (!name.value || !email.value) {
    document.getElementById("errors").textContent = "All fields are required!";
  } else {
    console.log("Registered for", event.value);
  }
});
