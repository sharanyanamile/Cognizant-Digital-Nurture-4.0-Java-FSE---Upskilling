
$(document).ready(function() {
  $('#registerBtn').click(function() {
    $('.eventCard').fadeIn().delay(1000).fadeOut();
  });
  console.log("Frameworks like React or Vue improve maintainability and scalability.");
});
