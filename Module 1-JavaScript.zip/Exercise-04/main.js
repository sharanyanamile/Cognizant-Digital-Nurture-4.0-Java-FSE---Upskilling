
function addEvent(name, category) {
  return { name, category, registered: 0 };
}

function registerUser(event) {
  event.registered++;
  return event;
}

function filterEventsByCategory(events, category) {
  return events.filter(e => e.category === category);
}

// Closure example
function registrationTracker(category) {
  let total = 0;
  return function register() {
    total++;
    console.log(`${category} total registrations: ${total}`);
  };
}

const tracker = registrationTracker("Music");
tracker();
tracker();

// Higher-order function
function filter(events, callback) {
  return events.filter(callback);
}
