
function Event(name, date, seats) {
  this.name = name;
  this.date = date;
  this.seats = seats;
}

Event.prototype.checkAvailability = function() {
  return this.seats > 0;
};

const event = new Event("Art Show", "2025-07-10", 30);
console.log(Object.entries(event));
console.log("Available?", event.checkAvailability());
