
function submitForm() {
  console.log("Submitting...");
  const payload = { name: "Test", event: "Demo" };
  console.log("Payload:", payload);
  fetch("https://jsonplaceholder.typicode.com/posts", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload)
  })
  .then(res => res.json())
  .then(data => console.log("Response:", data))
  .catch(err => console.error("Network error:", err));
}

submitForm();
