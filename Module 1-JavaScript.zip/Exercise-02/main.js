
const eventName = "Music Festival";
const eventDate = "2025-06-15";
let seats = 100;

console.log(`Event: ${eventName} on ${eventDate}, Seats available: ${seats}`);

seats--;
console.log(`After registration, seats left: ${seats}`);
