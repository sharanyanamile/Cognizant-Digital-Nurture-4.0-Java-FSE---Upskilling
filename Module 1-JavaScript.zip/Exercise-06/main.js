
const events = [
  { name: "Cooking", type: "Workshop" },
  { name: "Jazz Night", type: "Music" }
];

events.push({ name: "Baking", type: "Workshop" });

const musicEvents = events.filter(e => e.type === "Music");
const formatted = events.map(e => `${e.type} on ${e.name}`);
console.log(musicEvents, formatted);
