
const events = [
  { name: "Yoga Class", date: "2025-07-01", seats: 10 },
  { name: "Old Event", date: "2023-05-20", seats: 0 }
];

events.forEach(event => {
  const today = new Date();
  const eventDate = new Date(event.date);
  if (eventDate > today && event.seats > 0) {
    console.log(`Upcoming Event: ${event.name}`);
  } else {
    console.log(`Skipping event: ${event.name}`);
  }
});

try {
  let registered = true;
  if (!registered) throw new Error("Registration failed");
  console.log("Registration successful");
} catch (error) {
  console.error(error.message);
}
