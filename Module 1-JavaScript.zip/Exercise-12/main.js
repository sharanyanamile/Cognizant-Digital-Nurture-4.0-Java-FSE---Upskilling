
function registerUser(data) {
  setTimeout(() => {
    fetch("https://jsonplaceholder.typicode.com/posts", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data)
    })
    .then(res => res.json())
    .then(res => console.log("Success:", res))
    .catch(err => console.error("Error:", err));
  }, 1000);
}

registerUser({ name: "Alice", event: "Jazz Night" });
