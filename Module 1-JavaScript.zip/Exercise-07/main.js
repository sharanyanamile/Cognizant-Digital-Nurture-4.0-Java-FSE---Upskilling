
const events = [
  { name: "Marathon" },
  { name: "Book Reading" }
];

const container = document.querySelector("#events");
events.forEach(e => {
  const div = document.createElement("div");
  div.textContent = e.name;
  container.appendChild(div);
});
