package com.utils;

public class Utils {
    public static String getWelcomeMessage(String name) {
        return "Hello, " + name + "! Welcome to Java Modules.";
    }
}
